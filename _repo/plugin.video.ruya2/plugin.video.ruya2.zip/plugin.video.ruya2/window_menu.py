# -*- coding: utf-8 -*-

import os
import sys
import urlparse,urllib,urllib2

import xbmc
import xbmcgui
import xbmcaddon

import windowtools
from windowtools import *

import plugintools
import navigation
from item import Item

class MenuWindow(xbmcgui.WindowXML):

    def __init__(self, xml_name, fallback_path):
        plugintools.log("MenuWindow.__init__ xml_name="+xml_name+" fallback_path="+fallback_path)

        self.first_time = False
        self.parent_item = None

        self.itemlist = None

    def setParentItem(self,item):
        self.parent_item = item

    def setItemlist(self,itemlist):
        plugintools.log("MenuWindow.setItemlist")

        self.itemlist = []

        for item in itemlist:
            plugintools.log("MenuWindow.setItemlist item="+item.tostring())
            self.itemlist.append(item)

    def onInit( self ):
        plugintools.log("MenuWindow.onInit")

        if self.first_time == True:
            return
        
        self.first_time = True

        self.control_list = self.getControl(100)

        if self.itemlist is None:
            next_items = navigation.get_next_items( self.parent_item )
            self.setItemlist(next_items)

        for item in self.itemlist:

            plugintools.log("MenuWindow.onInit title="+item.title+", icon="+item.thumbnail)

            list_item = xbmcgui.ListItem( item.title , iconImage=item.thumbnail, thumbnailImage=item.thumbnail)

            info_labels = { "Title" : item.title, "Plot" : item.plot }
            list_item.setInfo( "video", info_labels )

            self.control_list.addItem(list_item)

        self.setFocusId(100)
        self.getControl(400).setVisible(False)

        if self.parent_item.action=="mainlist" and plugintools.get_setting("update_checked")=="false":
            
            plugintools.set_setting("update_checked","true")
            import updater
            updater.check_for_updates()

    def onAction(self, action):
        plugintools.log("MenuWindow.onAction action.id="+repr(action.getId())+" action.buttonCode="+repr(action.getButtonCode()))

        if action == ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2:
            self.close()

        pos = self.control_list.getSelectedPosition()

        if pos>len(self.itemlist):
            return

        item = self.itemlist[pos]
        
        if action == ACTION_SELECT_ITEM or action == ACTION_MOUSE_LEFT_CLICK:

            if self.getFocusId()==100:
                pos = self.control_list.getSelectedPosition()
                item = self.itemlist[pos]

                next_window = navigation.get_window_for_item( item )
                next_window.setParentItem(item)
                navigation.push_window(next_window)

                next_window.doModal()
                del next_window

            # Search
            elif self.getFocusId()==301:
                text_to_search = plugintools.keyboard_input("","Type what you want to search for")

                if text_to_search=="":
                    return

                item = Item( action="globalsearch" , url=text_to_search, view="menu" )

                next_window = navigation.get_window_for_item( item )
                next_window.setParentItem(item)
                navigation.push_window(next_window)

                next_window.doModal()
                del next_window

            # Settings
            elif self.getFocusId()==302:
                if plugintools.get_setting("pincode")!="":
                    typed = plugintools.keyboard_input("","Enter PIN for settings",hidden=True)
                    if typed==plugintools.get_setting("pincode"):
                        plugintools.open_settings_dialog()
                else:
                    plugintools.open_settings_dialog()

            # Home
            elif self.getFocusId()==303:
                navigation.go_to_home_window()

    def onFocus( self, control_id ):
        plugintools.log("MenuWindow.onFocus "+repr(control_id))
        pass

    def onClick( self, control_id ):
        plugintools.log("MenuWindow.onClick "+repr(control_id))
        pass

    def onControl(self, control):
        plugintools.log("MenuWindow.onClick "+repr(control))
        pass
