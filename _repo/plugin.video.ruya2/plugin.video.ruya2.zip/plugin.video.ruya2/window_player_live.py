# -*- coding: utf-8 -*-

import os
import sys
import urlparse,urllib,urllib2
import threading
import time
import random

import xbmc
import xbmcgui
import xbmcaddon

import windowtools
from windowtools import *
from item import Item

import plugintools
import navigation
import custom_player
import api

class PlayerLiveWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, xml_name, fallback_path):
        plugintools.log("PlayerLiveWindow.__init__ xml_name="+xml_name+" fallback_path="+fallback_path)

        self.itemlist = []
        self.current_item_index = 0

        self.category_itemlist = []
        self.current_category_item_index = 0

        self.parent_item = None

        self.custom_player = None

        self.osd_visible = True
        self.channel_list_visible = True
        self.channel_detail_visible = True

        self.hide_osd_timer = None
        self.zap_timer = None

        self.zapping = False

        self.showing_channel_detail_for_current_channel = False

    def setParentItem(self,item):
        self.parent_item = item

    def setItemlist(self,itemlist):
        plugintools.log("PlayerLiveWindow.setItemlist")

        self.itemlist = itemlist

    def onInit( self ):
        plugintools.log("PlayerLiveWindow.onInit")

        if len(self.itemlist)==0:
            plugintools.log("PlayerLiveWindow.onInit No channels, clsing")
            self.close()
            return

        self.hide_channel_list()
        self.hide_channel_detail()

        self.category_list = self.getControl(201)

        self.category_itemlist.append( Item(title="Search...",index=-1) )
        self.category_list.addItem( xbmcgui.ListItem( "Search..." ) )

        self.category_itemlist.append( Item(title="Recently viewed",index=-1) )
        self.category_list.addItem( xbmcgui.ListItem( "Recently viewed" ) )

        self.category_itemlist.append( Item(title="Favorites",index=-1) )
        self.category_list.addItem( xbmcgui.ListItem( "Favorites" ) )
        last_category = ""

        self.control_list = self.getControl(202)

        self.channel_events = self.getControl(502)

        counter = 0
        for item in self.itemlist:
            plugintools.log("PlayerLiveWindow.setItemlist item="+item.tostring())

            thumbnail = api.get_main_url() + "/img/thumbnail.php?t=channel&id="+item.id+"&w=85&h=48"

            title = ""
            if item.title is not None and item.title.strip()<>"":
                title += "[COLOR ffffffff]"+plugintools.htmlclean(item.title)+"[/COLOR]\n"
            else:
                title += "[COLOR ffffffff](Channel name not available)[/COLOR]\n"

            if item.current_local_start is not None and item.current_title is not None:
                title += "Now: "+item.current_local_start+" "+plugintools.htmlclean(item.current_title)

            if item.next_local_start is not None and item.next_title is not None:
                title += "[COLOR ff9099b7] - Next: "+item.next_local_start+" "+item.next_title+"[/COLOR]"

            list_item = xbmcgui.ListItem( title , iconImage=thumbnail, thumbnailImage=thumbnail)
            self.control_list.addItem(list_item)

            if item.category!=last_category:
                last_category = item.category
                self.category_list.addItem( xbmcgui.ListItem( last_category ) )
                self.category_itemlist.append( Item(title=last_category,index=counter) )

            if str(item.id)==plugintools.get_setting("last_channel_id"):
                self.current_item_index = counter

            counter = counter + 1

        self.update_osd()
        self.show_osd()

        # Lanza el vídeo
        self.custom_player = custom_player.CustomPlayer()
        self.custom_player.set_listener(self)
        self.play_current_channel()

        if plugintools.get_setting("clean_recently_viewed_channels")=="true":
            plugintools.set_setting("clean_recently_viewed_channels","false")
            api.channels_clear_recently_watched()

        self.getControl(400).setVisible(False)

    def select_channel(self,channel_id):
        plugintools.log("PlayerLiveWindow.select_channel channel_id="+str(channel_id))

        counter = 0
        for item in self.itemlist:
            if item.id==channel_id:
                self.zap_to_channel_sync( counter )
                break
            counter = counter + 1

    def select_first_channel_of_category(self,category_index):
        plugintools.log("PlayerLiveWindow.select_first_channel_of_category category_index="+str(category_index))

        category_item = self.category_itemlist[category_index]
        self.control_list.selectItem(category_item.index)
        self.setFocusId(202)

    def get_current_channel(self):
        return self.itemlist[self.current_item_index]

    def onAction(self, action):
        plugintools.log("PlayerLiveWindow.onAction action="+windowtools.action_to_string(action))

        # Press OK
        if action == ACTION_SELECT_ITEM:

            # Channel detail visible
            if self.channel_detail_visible:
                return

            # Channel list is visible
            elif self.channel_list_visible:
                plugintools.log("PlayerLiveWindow.onAction channel_list_visible=True, focus en "+str(self.getFocusId()))

                # Channel list is focused, zap to that channel
                if self.getFocusId()==202:
                    self.set_osd_visible(False)
                    self.hide_channel_list()

                    self.zap_to_channel_sync( self.control_list.getSelectedPosition() )

                # Category list is focused, move selection to first channel of that category
                elif self.getFocusId()==201:

                    # Search
                    if self.category_list.getSelectedPosition()==0:
                        text_to_search = plugintools.keyboard_input("","Type channel to search for")

                        if text_to_search=="":
                            return

                        itemlist = api.channels_search(text_to_search)

                        if len(itemlist)>0:
                            options = []
                            for item in itemlist:
                                options.append(item.title)

                            option = plugintools.selector(options,"Search results")
                            plugintools.log("PlayerLiveWindow.onAction option="+str(option))

                            if option==-1:
                                return

                            self.select_channel(itemlist[option].id)
                        else:
                            plugintools.message("No recently watched channels")

                    # Recently viewed
                    elif self.category_list.getSelectedPosition()==1:
                        itemlist = api.channels_get_recently_watched()

                        if len(itemlist)>0:
                            options = []
                            for item in itemlist:
                                options.append(item.title)

                            option = plugintools.selector(options,"Select one option")
                            plugintools.log("PlayerLiveWindow.onAction option="+str(option))

                            if option==-1:
                                return

                            self.select_channel(itemlist[option].id)
                        else:
                            plugintools.message("No recently watched channels")

                    # Favorites
                    elif self.category_list.getSelectedPosition()==2:

                        itemlist = api.channels_get_favorites()

                        if len(itemlist)>0:
                            options = []
                            for item in itemlist:
                                options.append(item.title)

                            option = plugintools.selector(options,"Favorites")
                            plugintools.log("PlayerLiveWindow.onAction option="+str(option))

                            if option==-1:
                                return

                            self.select_channel(itemlist[option].id)
                        else:
                            plugintools.message("No recently watched channels")

                    self.select_first_channel_of_category( self.category_list.getSelectedPosition() )

            else:
                self.toogle_osd_visible()

        # Mouse movement show OSD
        if action == ACTION_MOUSEMOVE2:

            if not self.osd_visible and not self.channel_detail_visible:
                self.set_osd_visible(True)

        # Mouse click or touch show OSD
        if action == ACTION_MOUSE_LEFT_CLICK or action==ACTION_TOUCH_TAP:

            if self.channel_detail_visible:
                return
            elif not self.osd_visible:
                self.set_osd_visible(True)
            elif not self.channel_list_visible:
                self.show_channel_list()
                self.cancel_osd_hide_timer()
            else:
                if self.getFocusId()==202 or self.getFocusId()==201:
                    self.onAction( ACTION_SELECT_ITEM )

        if action == ACTION_CONTEXT_MENU:

            # Channel list is visible
            if not self.channel_list_visible and not self.channel_detail_visible:

                options = []

                if self.get_current_channel().is_favorite=="true":
                    options.append("Remove channel to favorites")
                else:
                    options.append("Add channel to favorites")

                audio_streams = self.custom_player.getAvailableAudioStreams()
                index = 1
                for audio_stream in audio_streams:
                    options.append("Audio: "+audio_stream+" ("+str(index)+")")
                    index = index + 1

                subtitle_streams = self.custom_player.getAvailableSubtitleStreams()
                index = 1
                for subtitle_stream in subtitle_streams:
                    options.append("Subtitle: "+subtitle_stream+" ("+str(index)+")")
                    index = index + 1
                options.append("Disable subtitles")

                option = plugintools.selector(options,"Select one option")
                plugintools.log("PlayerLiveWindow.onAction option="+str(option))

                if option==-1:
                    return

                plugintools.log("PlayerLiveWindow.onAction option="+options[option])

                if option==0:
                    if self.get_current_channel().is_favorite=="true":
                        api.favorites_remove("channel" , self.get_current_channel().id )
                        plugintools.show_notification(self.get_current_channel().title,"Removed from favorites")
                    else:
                        api.favorites_add("channel" , self.get_current_channel().id )
                        plugintools.show_notification(self.get_current_channel().title,"Added to favorites")

                elif options[option]=="Disable subtitles":
                    plugintools.log("PlayerLiveWindow.onAction switch off subtitles")
                    self.custom_player.showSubtitles(False)

                elif options[option].startswith("Audio:"):
                    index = plugintools.find_single_match(options[option],"\((\d+)\)$")
                    aindex = int(index)-1
                    plugintools.log("PlayerLiveWindow.onAction change audio to "+str(aindex))
                    self.custom_player.setAudioStream( aindex )

                elif options[option].startswith("Subtitle:"):
                    index = plugintools.find_single_match(options[option],"\((\d+)\)$")
                    sindex = int(index)-1

                    plugintools.log("PlayerLiveWindow.onAction change subtitles to "+str(sindex))
                    self.custom_player.showSubtitles(True)
                    self.custom_player.setSubtitleStream( index )

        elif action == ACTION_STOP:
            try:
                self.custom_player.stop()
            except:
                pass

            plugintools.set_setting("last_channel_id",self.get_current_channel().id)
            self.close()

        elif action == ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2:

            # Close channel list
            if self.channel_detail_visible:

                if self.showing_channel_detail_for_current_channel:
                    self.hide_channel_detail()
                    self.hide_channel_list()
                    self.hide_osd()
                else:
                    self.hide_channel_detail()
                    self.show_channel_list()
                    self.show_osd()
                    self.cancel_osd_hide_timer()

            elif self.channel_list_visible:
                self.hide_channel_list()
                self.hide_osd()

            elif self.osd_visible:
                self.hide_osd()

            # Stops player and close
            else:
                self.close_and_exit()

        elif action == ACTION_MOVE_RIGHT:

            # If only infobar is visible, right is zapping
            if not self.channel_list_visible and not self.channel_detail_visible:
                #self.zap_to_next_channel_async()
                self.zap_to_next_channel_sync()

            # Close channel detail
            if self.channel_detail_visible and self.showing_channel_detail_for_current_channel:
                self.hide_channel_detail()
                self.hide_channel_list()
                self.hide_osd()

        elif action == ACTION_MOVE_LEFT:
    
            if not self.channel_list_visible and not self.channel_detail_visible:
                #self.zap_to_previous_channel_async()
                self.zap_to_previous_channel_sync()

            # Close channel detail
            if self.channel_detail_visible and self.showing_channel_detail_for_current_channel:
                self.hide_channel_detail()
                self.hide_channel_list()
                self.hide_osd()

        elif action == ACTION_MOVE_UP:

            if not self.channel_list_visible and not self.channel_detail_visible:
                self.set_osd_visible(True)
                self.show_channel_list()
                self.cancel_osd_hide_timer()

        elif action == ACTION_MOVE_DOWN:

            if not self.channel_list_visible and not self.channel_detail_visible:
                self.hide_osd()

                # Show detail for currently selected channel
                self.showing_channel_detail_for_current_channel = True

                selected_channel =  self.itemlist[ self.current_item_index ]
                self.show_load_and_show_detail_for_channel(selected_channel)

    def close_and_exit(self):

        try:
            self.custom_player.stop()
        except:
            pass

        try:
            plugintools.set_setting("last_channel_id",self.get_current_channel().id)
        except:
            pass

        self.close()

    def set_current_channel_id(self,current_channel_id):
        self.current_channel_id = current_channel_id

    def get_current_channel_id(self):
        return self.current_channel_id

    def show_channel_list(self):
        plugintools.log("PlayerLiveWindow.show_channel_list")

        self.channel_list_visible = True

        self.control_list.selectItem(self.current_item_index)
        self.getControl(200).setVisible(True)
        self.getControl(102).setImage("livetv-osd-noarrows.png")

        self.setFocusId(202)

    def hide_channel_list(self):
        plugintools.log("PlayerLiveWindow.hide_channel_list")

        self.channel_list_visible = False
        self.getControl(200).setVisible(False)
        self.getControl(102).setImage("livetv-osd-arrows-both.png")

    def show_channel_detail(self):
        plugintools.log("PlayerLiveWindow.show_channel_detail")

        self.channel_detail_visible = True
        self.getControl(500).setVisible(True)
        self.setFocusId(502)

        if self.showing_channel_detail_for_current_channel:
            self.getControl(503).setImage("livetv-channel-detail-osd-noarrow.png")
            self.getControl(501).setVisible(False)
        else:
            self.getControl(503).setImage("livetv-channel-detail-osd.png")
            self.getControl(501).setVisible(True)

    def hide_channel_detail(self):
        plugintools.log("PlayerLiveWindow.hide_channel_list")

        self.channel_detail_visible = False
        self.getControl(500).setVisible(False)

    def zap_to_channel_async(self,new_index):
        plugintools.log("PlayerLiveWindow.zap_to_next_channel_async")
    
        # Primero salta al nuevo canal
        self.current_item_index = new_index
        self.update_osd()
        self.show_osd()

        # Y finalmente hace el zapping tras un pequeño delay
        if self.zap_timer is not None and self.zap_timer.is_alive():
            self.zap_timer.cancel()

        self.stop_and_play_current_channel()

    def zap_to_next_channel_async(self):
        plugintools.log("PlayerLiveWindow.zap_to_next_channel_async")
    
        # Primero salta al nuevo canal
        self.current_item_index = self.current_item_index + 1
        if self.current_item_index >= len(self.itemlist):
            self.current_item_index = 0

        self.update_osd()
        self.show_osd()

        # Y finalmente hace el zapping tras un pequeño delay
        if self.zap_timer is not None and self.zap_timer.is_alive():
            self.zap_timer.cancel()

        self.zap_timer = threading.Timer(0.5,self.stop_and_play_current_channel)
        self.zap_timer.setDaemon(True) 
        self.zap_timer.start()

    def zap_to_previous_channel_async(self):
        plugintools.log("PlayerLiveWindow.zap_to_previous_channel_async")

        self.show_osd()

        self.custom_player.stop()
        self.current_item_index = self.current_item_index - 1
        if self.current_item_index < 0:
            self.current_item_index = len(self.itemlist)-1

        self.play_current_channel()

    def zap_to_channel_sync(self,new_index):
        plugintools.log("PlayerLiveWindow.zap_to_channel_sync")
    
        if not self.zapping:
            self.zapping = True
        
            # Primero salta al nuevo canal
            self.current_item_index = new_index
            self.hide_channel_list()
            self.update_osd()
            self.show_osd()

            self.custom_player.stop()
            self.play_current_channel()

            self.zapping = False

    def zap_to_next_channel_sync(self):
        plugintools.log("PlayerLiveWindow.zap_to_next_channel_sync")
    
        if not self.zapping:
            self.zapping = True
        
            self.current_item_index = self.current_item_index + 1
            if self.current_item_index >= len(self.itemlist):
                self.current_item_index = 0

            self.update_osd()
            self.show_osd()

            self.custom_player.stop()
            self.play_current_channel()

            self.zapping = False

        plugintools.log("PlayerLiveWindow.zap_to_next_channel_sync Done")

    def zap_to_previous_channel_sync(self):
        plugintools.log("PlayerLiveWindow.zap_to_previous_channel_sync")

        if not self.zapping:
            self.zapping = True

            self.current_item_index = self.current_item_index - 1
            if self.current_item_index < 0:
                self.current_item_index = len(self.itemlist)-1

            self.update_osd()
            self.show_osd()

            self.custom_player.stop()
            self.play_current_channel()

            self.zapping = False

    def show_osd(self):
        plugintools.log("PlayerLiveWindow.show_osd")

        self.cancel_osd_hide_timer()

        self.set_osd_visible(True)
        self.hide_osd_timer = threading.Timer(5,self.hide_osd_after_delay)
        self.hide_osd_timer.setDaemon(True) 
        self.hide_osd_timer.start()

    def cancel_osd_hide_timer(self):
        plugintools.log("PlayerLiveWindow.cancel_osd_hide_timer")

        if self.hide_osd_timer is not None and self.hide_osd_timer.is_alive():
            self.hide_osd_timer.cancel()

    def hide_osd_after_delay(self):
        plugintools.log("PlayerLiveWindow.hide_osd_after_delay")

        self.set_osd_visible(False)
        self.hide_osd_timer = None

    def set_osd_visible(self, visible):
        plugintools.log("PlayerLiveWindow.set_osd_visible visible="+str(visible))

        if self.osd_visible!=visible:
            self.getControl(101).setVisible(visible)
            self.osd_visible = visible

        if not visible:
            self.cancel_osd_hide_timer()

    def hide_osd(self):
        self.set_osd_visible(False)

    def toogle_osd_visible(self):
        plugintools.log("PlayerLiveWindow.toogle_osd_visible")

        if self.osd_visible:
            self.set_osd_visible(False)
        else:
            self.set_osd_visible(True)

    def stop_and_play_current_channel( self ):
        plugintools.log("PlayerLiveWindow.stop_and_play_current_channel")

        current_channel = self.get_current_channel()
        response = api.remote_call( "stream/get.php" , { "t" : "channel" , "id" : current_channel.id } )
        plugintools.log("PlayerLiveWindow.stop_and_play_current_channel response="+repr(response))

        if response["error"]:
            self.close_and_exit()
            return

        url = response["body"]["url"]
        plugintools.log("PlayerLiveWindow.stop_and_play_current_channel url="+url)

        self.custom_player.stop()
        self.custom_player.play_stream( url )
        
    def play_current_channel( self ):
        plugintools.log("PlayerLiveWindow.play_current_channel")

        current_channel = self.get_current_channel()
        response = api.remote_call( "stream/get.php" , { "t" : "channel" , "id" : current_channel.id } )
        plugintools.log("PlayerLiveWindow.play_current_channel response="+repr(response))

        if response["error"]:
            self.close_and_exit()
            return

        url = response["body"]["url"]
        plugintools.log("PlayerLiveWindow.play_current_channel url="+url)

        self.custom_player.play_stream( url )
        self.update_osd()

    # Muestra y actualiza el OSD
    def update_osd( self ):
        plugintools.log("PlayerLiveWindow.update_osd")

        current_channel = self.get_current_channel()
        
        thumbnail = api.get_main_url() + "/img/thumbnail.php?t=channel&id="+current_channel.id+"&w=126&h=72"
        plugintools.log("PlayerLiveWindow.update_osd thumbnail="+thumbnail)

        self.getControl(103).setImage( thumbnail )

        temp_title = ""
        if current_channel.title is not None:
            temp_title = "[COLOR ff15366d]"+plugintools.htmlclean(current_channel.title)+"[/COLOR]"
        else:
            temp_title = "[COLOR ff15366d](Channel name not available)[/COLOR]"

        if current_channel.current_local_start is not None and current_channel.current_title is not None:
            self.getControl(104).setText( temp_title+" "+current_channel.current_local_start+" "+plugintools.htmlclean(current_channel.current_title) )
        else:
            self.getControl(104).setText( temp_title )

        if current_channel.next_local_start is not None and current_channel.next_title is not None:
            self.getControl(105).setText( "[COLOR ff15366d]NEXT:[/COLOR] "+current_channel.next_local_start+" "+plugintools.htmlclean(current_channel.next_title) )
			
        else:
            self.getControl(105).setText( "" )

        if current_channel.current_description is not None:
            self.getControl(106).setText( plugintools.htmlclean(current_channel.current_description.strip()) )
        else:
            self.getControl(106).setText( "" )

    def on_playback_stopped( self ):
        plugintools.log("PlayerLiveWindow.on_playback_stopped currentTime="+str(self.custom_player.get_current_time())+", totalTime="+str(self.custom_player.get_total_time()))
        #self.close()

    def on_playback_ended( self ):
        plugintools.log("PlayerLiveWindow.on_playback_ended")
        #self.close()

    def onFocus( self, control_id ):
        plugintools.log("PlayerLiveWindow.onFocus "+repr(control_id))

        if control_id==203:
            self.hide_osd()
            self.hide_channel_list()

            self.showing_channel_detail_for_current_channel = False

            # Show detail for currently selected channel
            selected_channel =  self.itemlist[ self.control_list.getSelectedPosition() ]
            self.show_load_and_show_detail_for_channel(selected_channel)

        elif control_id==501:

            if self.showing_channel_detail_for_current_channel:
                self.hide_channel_detail()
                self.hide_channel_list()
                self.hide_osd()
            else:
                self.hide_channel_detail()
                self.show_channel_list()
                self.show_osd()
                self.cancel_osd_hide_timer()

        pass

    def onClick( self, control_id ):
        plugintools.log("PlayerLiveWindow.onClick "+repr(control_id))

        pass

    def onControl(self, control):
        plugintools.log("PlayerLiveWindow.onControl "+repr(control))
        pass

    def show_load_and_show_detail_for_channel(self, selected_channel):
        plugintools.log("PlayerLiveWindow.show_load_and_show_detail_for_channel selected_channel="+selected_channel.title)

        # Loader show
        self.getControl(400).setVisible(True)

        try:
            events_itemlist = api.channel_get_next_events(selected_channel.id)
        except:
            events_itemlist = []

        # Loader hide
        self.getControl(400).setVisible(False)

        self.show_channel_detail()

        self.getControl(510).setText("")
        self.channel_events.reset()

        if selected_channel.title is not None:
            now_description = "[COLOR ffffcf70]"+plugintools.htmlclean(selected_channel.title)+"[/COLOR]"
        else:
            now_description = "[COLOR ffffcf70](Channel name not available)[/COLOR]"

        if selected_channel.current_local_start is not None and selected_channel.current_title is not None:
            now_description += " - "+selected_channel.current_local_start+" "+plugintools.htmlclean(selected_channel.current_title)
        
        if selected_channel.current_description is not None:
            now_description += "\n[COLOR ff9099b7]"+plugintools.htmlclean(selected_channel.current_description.strip())+"[/COLOR]"

        self.getControl(510).setText(now_description)

        for event_item in events_itemlist:
            event_description = ""

            if event_item.local_start is not None and event_item.title is not None:
                event_description += event_item.local_start+" "+plugintools.htmlclean(event_item.title)+"\n"

            if event_item.description is not None:
                event_description += "[COLOR ff9099b7]"+event_item.description+"[/COLOR]"

            self.channel_events.addItem( xbmcgui.ListItem( event_description ) )

        self.setFocusId(502)
