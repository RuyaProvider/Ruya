# -*- coding: utf-8 -*-
#------------------------------------------------------------

import urlparse,urllib2,urllib,re
import os
import sys
import plugintools
import xbmc

REMOTE_VERSION_FILE = "http://"+plugintools.get_setting("server")+":88/ruya2/api/packages/version-kodi.txt"
LOCAL_VERSION_FILE = os.path.join( plugintools.get_runtime_path() , "version.txt")

def check_for_updates():
    plugintools.log("ruya2.updater checkforupdates")

    # Descarga el fichero con la versión en la web
    try:
        plugintools.log("ruya2.updater remote_version_file="+REMOTE_VERSION_FILE)
        data = plugintools.read( REMOTE_VERSION_FILE )

        remote_version = data.splitlines()[0]
        remote_file_url = data.splitlines()[1]
        plugintools.log("ruya2.updater remote_version="+remote_version+" "+remote_file_url)
        
        # Lee el fichero con la versión instalada
        #plugintools.log("ruya2.updater local_version_file="+LOCAL_VERSION_FILE)
        infile = open( LOCAL_VERSION_FILE )
        data = infile.read()
        infile.close();

        local_version = data.splitlines()[0]
        plugintools.log("ruya2.updater version local_version="+local_version)

        if int(remote_version)>int(local_version):
            plugintools.log("ruya2.updater update found")
            
            yes_pressed = plugintools.message_yes_no("RuYa IPTV","An update is available!","Do you want to install it now?")

            if yes_pressed:
                try:
                    plugintools.log("ruya2.updater Download file...")
                    local_file_name = os.path.join( plugintools.get_data_path() , "update.zip" )
                    urllib.urlretrieve(remote_file_url, local_file_name )

                    if not os.path.exists(local_file_name):
                        plugintools.log("ruya2.updater Downloaded file not found")
                        raise Exception()

                    # Lo descomprime
                    plugintools.log("ruya2.updater Unzip file...")

                    import ziptools
                    unzipper = ziptools.ziptools()
                    destpathname = xbmc.translatePath( "special://home/addons")
                    plugintools.log("ruya2.updater destpathname=%s" % destpathname)
                    unzipper.extract( local_file_name , destpathname )
                    
                    xbmc.executebuiltin((u'XBMC.Notification("Updated", "Please restart add-on to see the changes", 2000)'))
                    xbmc.executebuiltin( "Container.Refresh" )
                except:
                    xbmc.executebuiltin((u'XBMC.Notification("Not updated", "An error causes the update to fail", 2000)'))

                if os.path.exists(local_file_name):
                    plugintools.log("ruya2.updater delete downloaded file...")
                    os.remove(local_file_name)
                    plugintools.log("ruya2.updater ...file deleted")


    except:
        import traceback
        plugintools.log(traceback.format_exc())
