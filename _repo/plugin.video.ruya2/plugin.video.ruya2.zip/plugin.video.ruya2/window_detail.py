# -*- coding: utf-8 -*-

import os
import sys
import urlparse,urllib,urllib2

import xbmc
import xbmcgui
import xbmcaddon

import windowtools
from windowtools import *

import plugintools
import navigation
from item import Item

import api
import custom_player

class DetailWindow(xbmcgui.WindowXML):

    def __init__(self, xml_name, fallback_path):
        plugintools.log("DetailWindow.__init__ xml_name="+xml_name+" fallback_path="+fallback_path)

        self.first_time = False
        self.parent_item = None

        self.itemlist = None
        self.custom_player = None

    def setParentItem(self,item):
        self.parent_item = item

    def setItemlist(self,itemlist):
        plugintools.log("DetailWindow.setItemlist")

        self.itemlist = []

        for item in itemlist:
            plugintools.log("DetailWindow.setItemlist item="+item.tostring())
            self.itemlist.append(item)

    def onInit( self ):
        plugintools.log("DetailWindow.onInit")

        if self.custom_player is not None:
            plugintools.log("DetailWindow.onInit custom player active")
            if self.custom_player.isPlaying():
                plugintools.log("DetailWindow.onInit custom player playing")
                self.custom_player.stop()
            else:
                plugintools.log("DetailWindow.onInit custom player not playing")
                self.custom_player.stop()
        else:
            plugintools.log("DetailWindow.onInit custom player inactive")

        if self.first_time == True:
            return
        
        self.first_time = True

        self.getControl(404).setImage( self.parent_item.thumbnail )
        self.getControl(405).setText( "[COLOR ffffcf70]"+plugintools.htmlclean(self.parent_item.title)+"[/COLOR]\n\n"+plugintools.htmlclean(self.parent_item.plot) )

        if self.parent_item.content_type=="catchup":
            self.getControl(406).setVisible(False)
            self.getControl(403).setVisible(False)
        else:
            if self.parent_item.watched=="true":
                self.getControl(406).setImage( "watched2.png" )

            if self.parent_item.is_favorite=="true":
                self.getControl(403).setLabel( "Remove from favorites" )
            else:
                self.getControl(403).setLabel( "Add to favorites" )

        self.setFocusId(401)

    def onAction(self, action):
        plugintools.log("DetailWindow.onAction action="+windowtools.action_to_string(action))

        if action == ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2:
            self.close()

        if action == ACTION_SELECT_ITEM or action == ACTION_MOUSE_LEFT_CLICK:

            # Watch in SD
            if self.getFocusId()==401:

                play_item = self.parent_item.clone()
                play_item.url = api.append_session_to_url(play_item.url)+"&quality=low"

                self.custom_player = custom_player.CustomPlayer()
                self.custom_player.set_listener(self)
                self.custom_player.play_item(play_item)

            # Watch in HD
            elif self.getFocusId()==402:
                play_item = self.parent_item.clone()
                play_item.url = api.append_session_to_url(play_item.url)+"&quality=high"

                self.custom_player = custom_player.CustomPlayer()
                self.custom_player.set_listener(self)
                self.custom_player.play_item(play_item)

            # Add/remove favorites
            elif self.getFocusId()==403:

                content_id = self.parent_item.id
                if (self.parent_item.content_type=="serie"):
                    content_id = self.parent_item.id_serie

                if self.parent_item.is_favorite=="true":
                    api.favorites_remove("movie",content_id)
                    plugintools.show_notification(self.parent_item.title,"Removed from favorites")
                    self.parent_item.is_favorite="false"
                    self.getControl(403).setLabel( "Add to favorites" )
                else:
                    api.favorites_add("movie",content_id)
                    plugintools.show_notification(self.parent_item.title,"Added to favorites")
                    self.parent_item.is_favorite="true"
                    self.getControl(403).setLabel( "Remove from favorites" )

            # Search
            elif self.getFocusId()==301:
                text_to_search = plugintools.keyboard_input("","Type what you want to search for")

                if text_to_search=="":
                    return

                item = Item( action="globalsearch" , url=text_to_search, view="menu" )

                next_window = navigation.get_window_for_item( item )
                next_window.setParentItem(item)
                navigation.push_window(next_window)

                next_window.doModal()
                del next_window

            # Settings
            elif self.getFocusId()==302:
                plugintools.open_settings_dialog()

            # Home
            elif self.getFocusId()==303:
                navigation.go_to_home_window()

    def onFocus( self, control_id ):
        plugintools.log("DetailWindow.onFocus "+repr(control_id))

    def onClick( self, control_id ):
        plugintools.log("DetailWindow.onClick "+repr(control_id))
        pass

    def onControl(self, control):
        plugintools.log("DetailWindow.onClick "+repr(control))
        pass

    def on_playback_stopped( self ):
        plugintools.log("DetailWindow.on_playback_stopped currentTime="+str(self.custom_player.get_current_time())+", totalTime="+str(self.custom_player.get_total_time()))
        self.custom_player = None

    def on_playback_ended( self ):
        plugintools.log("DetailWindow.on_playback_ended")
        self.custom_player = None
