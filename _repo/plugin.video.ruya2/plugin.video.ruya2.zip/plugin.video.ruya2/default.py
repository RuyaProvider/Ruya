# -*- coding: utf-8 -*-

import os

import plugintools
import navigation
import api

from api import UserException
from item import Item

plugintools.application_log_enabled = (plugintools.get_setting("debug")=="true")
plugintools.module_log_enabled = (plugintools.get_setting("debug")=="true")
plugintools.http_debug_log_enabled = (plugintools.get_setting("debug")=="true")

# Trace entry point
plugintools.log("ruya2.default")

def start():

    # If login details are not complete, ask for them
    if plugintools.get_setting("server")=="" or plugintools.get_setting("username")=="" or plugintools.get_setting("password")=="":
        plugintools.open_settings_dialog()

        if plugintools.get_setting("server")=="" or plugintools.get_setting("username")=="" or plugintools.get_setting("password")=="":
            return

    # Do login
    response = api.login()

    # If invalid, clear password so settings dialog is shown again on enter
    if response["error"]:
        plugintools.message(response["error_message"])
        plugintools.set_setting("password","")
        return

    # If allow adult is set to "Yes, until next restart" we set it now to "No"
    if plugintools.get_setting("allow_adult")=="2":
        plugintools.set_setting("allow_adult","0")

    # Flag for checking version once when plugin is opened
    plugintools.set_setting("update_checked","false")

    # Get items for main menu
    item = Item( action="mainlist" , view="menu" )

    try:
        itemlist = navigation.get_next_items( item )

        # Open main window
        window = navigation.get_window_for_item( item )
        window.setParentItem(item)
        window.setItemlist(itemlist)
        navigation.push_window(window)

        window.doModal()
        del window

    except UserException,e:
        import xbmcgui
        xbmcgui.Dialog().ok ("Error", e.value)

start()