# -*- coding: utf-8 -*-
#------------------------------------------------------------

import os
import sys
import urlparse
import plugintools

import urllib
from item import Item

API_KEY = "hC2244arh65FQ4h"
DEFAULT_HEADERS = [ ["User-Agent","ruya 2 kodi" ] ]

# ---------------------------------------------------------------------------------------------------------
#  User exception for user message propagation
# ---------------------------------------------------------------------------------------------------------

class UserException(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value) 

# ---------------------------------------------------------------------------------------------------------
#  Common function for API calls
# ---------------------------------------------------------------------------------------------------------
def get_main_url():
    return "http://"+plugintools.get_setting("server")+":88/ruya2/api"

def append_session_to_url(url):

    if url.endswith(".php") or url.endswith(".m3u8"):
        url = url + "?"
    else:
        url = url + "&"

    url = url + "d=kodi&s="+plugintools.get_setting("session")+"&o="+plugintools.get_setting("server")

    return url

# Make a remote call using post, ensuring api key is here
def remote_call(url,parameters={},require_session=True):
    plugintools.log("ruya2.api.remote_call url="+url+", parameters="+repr(parameters))

    if not url.startswith("http"):
        url = get_main_url() + "/" + url

    if not "api_key" in parameters:
        parameters["api_key"] = API_KEY

    # Add session token if not here
    if not "s" in parameters and require_session:
        parameters["s"] = plugintools.get_setting("session")

    if not "d" in parameters:
        parameters["d"] = "kodi"

    if not "o" in parameters:
        parameters["o"] = plugintools.get_setting("server")

    if not "tz" in parameters:
        parameters["tz"] = plugintools.get_setting("timezone")

    headers = DEFAULT_HEADERS
    post = urllib.urlencode(parameters)

    response_body,response_headers = plugintools.read_body_and_headers(url,post,headers)

    return plugintools.load_json(response_body)

# Make a remote call for loading next items
def get_items(item):
    plugintools.log("ruya2.api.get_items item="+item.tostring())

    # Break the GET URL for building a POST request
    plugintools.log("ruya2.api.get_items item.url="+item.url)
    parameters = {}
    if "?" in item.url:
        plugintools.log("ruya2.api.get_items item.url.split="+repr(item.url.split("?")))
        url = item.url.split("?")[0]
        parameter_list = urlparse.parse_qsl( item.url.split("?")[1] )
        for parameter in parameter_list:
            parameters[parameter[0]] = parameter[1]

        plugintools.log("ruya2.api.get_items parameters="+repr(parameters))
    else:
        url = item.url

    # Make the call
    json_response = remote_call( url , parameters )

    # Treat invalid data error
    if json_response["error"]:
        raise UserException(json_response["error_message"])

    return parse_itemlist_from_response(json_response)

def remote_call_and_get_items(url,parameters={}):
    plugintools.log("ruya2.api.remote_call_and_get_items url="+url+", parameters="+repr(parameters))
    
    json_response = remote_call(url,parameters)

    # Treat invalid data error
    if json_response["error"] and json_response["error_code"]=="400":
        raise UserException(json_response["error_message"])

    # Treat invalid authorization error
    if json_response["error"] and json_response["error_code"]=="403":
        raise InvalidAuthException(json_response["error_message"])

    return parse_itemlist_from_response(json_response)

# Parse the response JSON as a list if items
def parse_itemlist_from_response(json_response):
    plugintools.log("ruya2.api.parse_itemlist_from_response")

    itemlist = []
    for entry in json_response['body']:

        plugintools.log("ruya2.api.parse_itemlist_from_response entry="+repr(entry))
        
        item = Item()

        if "id" in entry:
            item.id = entry['id']

        if "title" in entry and entry['title'] is not None:
            item.title = entry['title']
        else:
            item.title = "(No title)"

        if "url" in entry and entry['url'] is not None:
            item.url = entry['url']
        else:
            item.url = ""

        if "thumbnail" in entry and entry['thumbnail'] is not None:
            item.thumbnail = entry['thumbnail']
        else:
            item.thumbnail = ""

        if "plot" in entry and entry['plot'] is not None:
            item.plot = entry['plot']
        else:
            item.plot = ""

        if "action" in entry:
            item.action = entry['action']

        if "category" in entry:
            item.category = entry['category']

        if "view" in entry:
            item.view = entry['view']            

        if "folder" in entry:
            item.folder = entry['folder']

        if "aired_date" in entry:
            item.aired_date = entry['aired_date']

        if "current_local_start" in entry:
            item.current_local_start = entry['current_local_start']

        if "local_start" in entry:
            item.local_start = entry['local_start']

        if "current_title" in entry:
            item.current_title = entry['current_title']

        if "current_description" in entry:
            item.current_description = entry['current_description']

        if "description" in entry:
            item.description = entry['description']

        if "next_local_start" in entry:
            item.next_local_start = entry['next_local_start']

        if "next_title" in entry:
            item.next_title = entry['next_title']

        if "favorite" in entry and entry['favorite']=="1":
            item.is_favorite = "true"
        else:
            item.is_favorite = "false"

        if "content_type" in entry:
            item.content_type = entry['content_type']
        else:
            item.content_type = ""

        if "id_serie" in entry:
            item.id_serie = entry['id_serie']

        if "watched" in entry and (entry['watched']==True or entry['watched']=="true"):
            item.watched = "true"
        else:
            item.watched = "false"

        if "folder" in entry:
            item.folder = entry['folder']

        plugintools.log("ruya2.api.parse_itemlist_from_response item="+item.tostring())

        itemlist.append( item )

    return itemlist

# ---------------------------------------------------------------------------------------------------------
#  special calls
# ---------------------------------------------------------------------------------------------------------

def get_main_list():
    plugintools.log("ruya2.api.get_main_list")

    parameters = { }

    return remote_call_and_get_items( "users/menu.php" , parameters )


def get_livetv_quality():

    quality = plugintools.get_setting("quality_for_livetv")
    
    if quality=="2":
        return "hd"
    elif quality=="1":
        return "sd"
    else:
        return "all"

def channels_list( id_current_channel ):
    plugintools.log("ruya2.api.channels_list")

    parameters = { "quality":get_livetv_quality() , "a":plugintools.get_setting("allow_adult") }

    return remote_call_and_get_items( "channels/list.php" , parameters )

def main_search( q ):
    plugintools.log("ruya2.api.main_search")

    parameters = { "q": q }

    return remote_call_and_get_items( "users/search.php" , parameters )

def favorites_add( content_type , content_id ):
    plugintools.log("ruya2.api.favorites_add content_type="+str(content_type)+", content_id="+str(content_id))

    parameters = { "type":str(content_type) , "id":str(content_id) }

    return remote_call( "favorites/add.php" , parameters )

def favorites_remove( content_type , content_id ):
    plugintools.log("ruya2.api.favorites_remove content_type="+str(content_type)+", content_id="+str(content_id))

    parameters = { "type":str(content_type) , "id":str(content_id) }

    return remote_call( "favorites/remove.php" , parameters )

def channels_get_favorites():
    plugintools.log("ruya2.api.channels_get_favorites")

    parameters = { }

    return remote_call_and_get_items( "channels/get_favorites.php" , parameters )

def channels_search( q ):
    plugintools.log("ruya2.api.channels_search")

    parameters = { "q":q }

    return remote_call_and_get_items( "channels/search.php" , parameters )

def channels_get_recently_watched():
    plugintools.log("ruya2.api.channels_get_recently_watched")

    parameters = { }

    return remote_call_and_get_items( "channels/get_recently_watched.php" , parameters )

def channels_clear_recently_watched():
    plugintools.log("ruya2.api.channels_clear_recently_watched")

    parameters = { }

    return remote_call_and_get_items( "channels/clear_recently_watched.php" , parameters )

def channel_get_next_events( channel_id ):
    plugintools.log("ruya2.api.channel_get_next_events");

    parameters = { "c": channel_id }
    return remote_call_and_get_items( "channels/get_next_events.php" , parameters )

# ---------------------------------------------------------------------------------------------------------
#  login
# ---------------------------------------------------------------------------------------------------------

def login():
    plugintools.log("ruya2.api.login")

    parameters = { "u":plugintools.get_setting("username") , "p":plugintools.get_setting("password") }

    response = remote_call( "users/login.php" , parameters , require_session=False )

    if not response["error"]:
        plugintools.set_setting( "session" , response["body"]["s"] )
    else:
        plugintools.set_setting( "session" , "" )

    return response
