# -*- coding: utf-8 -*-

import os
import sys
import urlparse,urllib,urllib2

import xbmc
import xbmcgui
import xbmcaddon

import plugintools
import api
from item import Item

window_stack = []

def push_window( window ):
    window_stack.append(window)

def pop_window():
    return window_stack.pop()

def go_to_home_window():
    plugintools.log("navigation.go_to_home_window")

    for i in range( len(window_stack)-1 ):
        plugintools.log("navigation.go_to_home_window Closing window "+str(i))
        window = window_stack.pop()
        window.close()

def get_next_items( item ):

    plugintools.log("navigation.get_next_items item="+item.tostring())

    try:
        # ----------------------------------------------------------------
        #  Main menu
        # ----------------------------------------------------------------
        if item.action=="mainlist":
            plugintools.log("navigation.get_next_items Main menu")
            itemlist = api.get_main_list()

        elif item.action=="livetv":
            plugintools.log("navigation.get_next_items Live TV")
            itemlist = api.channels_list( plugintools.get_setting("last_channel_id") )

        elif item.action=="globalsearch":
            plugintools.log("navigation.get_next_items Live TV")
            itemlist = api.main_search( item.url )

        #elif item.action=="stream_play":
        #    plugintools.direct_play( api.append_session_to_url(item.url) , title=item.title, thumbnail=item.thumbnail, plot=item.plot )
        #    itemlist = []

        else:
            plugintools.log("navigation.get_next_items Common action")
            itemlist = api.get_items(item)

    except:
        import traceback
        plugintools.log("navigation.get_next_items "+traceback.format_exc())
        itemlist = [ Item(title="Error", thumbnail=os.path.join( plugintools.get_runtime_path() , "resources" , "images" , "thumb_error.png" )) ]

    return itemlist

def get_window_for_item( item ):
    plugintools.log("navigation.get_window_for_item item="+item.tostring())

    # El menú principal va con banners + titulo
    if item.view=="menu":
        plugintools.log("navigation.get_window_for_item -> window_menu")
        import window_menu
        window = window_menu.MenuWindow("menu.xml",plugintools.get_runtime_path())

    elif item.view=="catchup" or item.view=="episodes":
        plugintools.log("navigation.get_window_for_item -> window_episodes")
        import window_episodes
        window = window_episodes.EpisodesWindow("episodes.xml",plugintools.get_runtime_path())

    elif item.view=="movies" or item.view=="series" or item.view=="seasons":
        plugintools.log("navigation.get_window_for_item -> window_posters")
        import window_posters
        window = window_posters.PostersWindow("posters.xml",plugintools.get_runtime_path())

    elif item.action=="livetv":
        plugintools.log("navigation.get_window_for_item -> window_player_background")
        import window_player_background
        window = window_player_background.PlayerWindowBackground("player_background.xml",plugintools.get_runtime_path())

    elif item.action=="stream_play":
        plugintools.log("navigation.get_window_for_item -> window_detail")
        import window_detail
        if item.content_type=="serie" or item.content_type=="catchup":
            window = window_detail.DetailWindow("detail_serie.xml",plugintools.get_runtime_path())
        else:
            window = window_detail.DetailWindow("detail_movie.xml",plugintools.get_runtime_path())
    else:
        import window_menu
        window = window_menu.MenuWindow("menu.xml",plugintools.get_runtime_path())

    return window
